package com.hw.photomovie.model;

/**
 * Created by huangwei on 2015/6/10.
 */
public class PhotoInfo {
    public Object extra;
    public String description;
}
