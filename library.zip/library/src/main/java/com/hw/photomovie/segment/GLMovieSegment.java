package com.hw.photomovie.segment;

import com.hw.photomovie.opengl.GLESCanvas;

/**
 * Created by huangwei on 2015/6/29.
 */
public abstract class GLMovieSegment extends MovieSegment<GLESCanvas> {
}
